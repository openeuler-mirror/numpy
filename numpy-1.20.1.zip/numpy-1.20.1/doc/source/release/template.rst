:orphan:

==========================
NumPy 1.xx.x Release Notes
==========================


Highlights
==========


New functions
=============


Deprecations
============


Future Changes
==============


Expired deprecations
====================


Compatibility notes
===================


C API changes
=============


New Features
============


Improvements
============


Changes
=======
