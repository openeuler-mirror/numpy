*********
Constants
*********

.. automodule:: numpy.doc.constants
