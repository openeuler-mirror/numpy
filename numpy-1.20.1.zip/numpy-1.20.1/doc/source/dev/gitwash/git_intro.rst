Install git
===========

Developing with git can be done entirely without github. Git is a distributed
version control system. In order to use git on your machine you must `install
it`_.

.. include:: git_links.inc
