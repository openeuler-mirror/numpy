#################
Using NumPy C-API
#################

.. toctree::

   c-info.how-to-extend
   c-info.python-as-glue
   c-info.ufunc-tutorial
   c-info.beyond-basics
