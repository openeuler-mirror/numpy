System Entropy
==============

.. module:: numpy.random.entropy

.. autofunction:: random_entropy
